yurongfu = 800
yurongfus = 100
niuzaiku = 200
niuzaikus = 150
chenshan = 300
chenshans = 200
jiake = 500
jiakes = 400
num = ((yurongfu * yurongfus) + (niuzaiku * niuzaikus) + (chenshan * chenshans) + (jiake * jiakes) )

print("-----------------------海澜之家----------------------------")
print("----------------------------------------------------------")
print("名称         价格           尺码           品质         数量")
print("羽绒服       ",yurongfu,"          xl             s         ",yurongfus)
print("牛仔裤       ",niuzaiku,"          xl             s         ",niuzaikus)
print("衬衫        ",chenshan,"          xl             s         ",chenshans)
print("夹克        ",jiake,"          xl             s         ",jiakes)
print("----------------------------------------------------------")
print("合计：",num,"￥")