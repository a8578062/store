apple = 2.0
apples = 200
orange = 0.8
oranges = 300
banana = 1.5
bananas = 250
lemon = 1.7
lemons = 150
strawberry = 2.0
strawberrys = 150
mango = 6.0
mangos = 300
grape = 8.0
grapes = 100
pineapple = 9.0
pineapples = 50
peach = 7.0
peachs = 500
sum = ((apple * apples) + (oranges * orange) + (banana * bananas) + (lemon * lemons)+ (strawberry * strawberrys)+ (mango * mangos)+ (pineapple * pineapples)+ (grape * grapes)+ (peach * peachs))

print("-----------------------水果商城----------------------------")
print("----------------------------------------------------------")
print("名称            价格                 品质               数量")
print("苹果           ",apple,"                 s                ",apples)
print("橘子           ",orange,"                 s                ",oranges)
print("香蕉           ",banana,"                 s                ",bananas)
print("柠檬           ",lemon,"                 s                ",lemons)
print("草莓           ",strawberry,"                 s                ",strawberrys)
print("芒果           ",mango,"                 s                ",mangos)
print("葡萄           ",grape,"                 s                ",grapes)
print("菠萝           ",pineapple,"                 s                ",pineapples)
print("桃子           ",peach,"                 s                ",peachs)
print("----------------------------------------------------------")
print("合计：",sum,"￥")
