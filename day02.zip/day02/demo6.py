num1 = 45
num2 = num1
print(num2)