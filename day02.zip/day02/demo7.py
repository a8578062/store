age = int(input("请输入年龄："))

if age >= 18:
    print("可以看电影")
else:
    print("年龄不合法！")