stu1 = 45
stu2 = 23
print(stu1 +stu2)