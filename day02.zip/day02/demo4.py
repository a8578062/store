num1 = 45
num2 = 23
num3 = 2
print(num1 + num2 + num3)