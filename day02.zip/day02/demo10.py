username = 'jason'
password = 'admin'
username1 = input("请输入用户名：")
password1 = input("请输入密码：")
if username1 == username and password == password1:
    print("登录成功")
else:
    print("用户名密码错误！")

