i = 0
a=[1,1,1,1,1,1,1,1,1,1]
while i <10:
    num = int(input("请输入一个数："))
    a[i] = num
    i = i+1

sum1 = a[0]+a[1]+a[2]+a[3]+a[4]+a[5]+a[6]+a[7]+a[8]+a[9]
print("十个数求和为：",sum1)


