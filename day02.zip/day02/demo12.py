
A = 56
B = 78
C = B-A
print("调换前  A=",A,"B=",B)
A = A + C
B = B - C
print("调换后  A=",A,"B=",B)
'''
i = 0
sum1 = 0
while i<10:
    sum = int(input("请输入一个数："))
    sum1 = sum1 + sum
    i = i + 1

print("十个数的和为：",sum1)
'''