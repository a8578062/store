import random
num1 = int(random.random() *100 + 50)
print(num1)