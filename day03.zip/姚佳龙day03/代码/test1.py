for i in range(6):
    for j in range(5-i):
        print(" ",end="")
    for n in range(i+1):
        print("*",end=" ")
    print("")