sum = 0
sum1 = 1
for i in range(1,21):
    sum1 = sum1*i
    sum = sum + sum1
print(sum)